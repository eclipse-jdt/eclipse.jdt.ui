/*******************************************************************************
 * Copyright (c) 2013 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
/**
 * The pack is a test package. This doc contains references like {@link Object} and  {@link Defaults#foo(String)} and tags
 * @deprecated use a pick
 * @author me
 *
 */
@org.eclipse.jdt.annotation.NonNullByDefault
@java.lang.Deprecated
@Generated("me")
package checkPackageInfo;