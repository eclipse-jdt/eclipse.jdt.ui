/*******************************************************************************
 * Copyright (c) 2013 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package JavadocHover_src.junit.javadochoverhtml;

import org.eclipse.jdt.annotation.NonNull;

import com.sun.mirror.apt.AnnotationProcessor;
import org.eclipse.jdt.ui.tests.PackageJavaDocTest;
import org.eclipse.jdt.ui.tests.html.PackagedocHtmlTest;
import org.eclipse.jdt.ui.tests.noJavadoc.TestClassNoJavaDoc;
import java.math.BigDecimal;

/**
 * Something about this class has to be documented here.
 * @author me
 *
 */
public class JavaDocHoverTest {
	
	@NonNull
	public String getValue(){
		AnnotationProcessor proc;
		InputStream in;
		BigDecimal bigDec;
		PackageJavaDocTest test;
		PackagedocHtmlTest test2;
		return "something";
	}

}
