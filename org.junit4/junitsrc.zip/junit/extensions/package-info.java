/**
 * Provides extended functionality for JUnit v3.x.
 */
package junit.extensions;