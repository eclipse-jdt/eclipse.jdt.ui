/**
 * Provides JUnit v3.x core classes.
 */
package junit.framework;