package one.two.three;

import java.util.Date;

public class MyDate {
	
	public String getDateText() {
		return new Date().toString();
	}

}
